const express = require('express');
const produtoService = require('../services/produtoService'); 
const router = express.Router();

// Rota para listar todos os produtos
router.get('/', authenticateToken, async (req, res) => {
    try {
        const produtos = await produtoService.getProdutos();
        res.json(produtos);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Rota para criar um novo produto
router.post('/', authenticateToken, async (req, res) => {
    const { nome, preco, descricao, categoria } = req.body;
    try {
        const produto = await produtoService.createProduto(nome, preco, descricao, categoria);
        res.status(201).json(produto);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
