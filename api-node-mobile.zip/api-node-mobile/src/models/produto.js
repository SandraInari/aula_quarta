const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Produto = sequelize.define('Produtos', {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            len: [10, 60] // Valida se o nome tem entre 10 e 60 caracteres
        }
    },
    preco: {
        type: DataTypes.FLOAT,
        allowNull: false,
        validate: {
            isFloat: true, // Garante que seja um número (valor decimal)
            
        }
    },
    descricao: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            len: [10, 500] // Valida se a descrição tem entre 10 e 500 caracteres
        }
    },
    categoria: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            len: [10, 30] // Valida se a categoria tem entre 10 e 30 caracteres
        }
    }
});

module.exports = Produto;
